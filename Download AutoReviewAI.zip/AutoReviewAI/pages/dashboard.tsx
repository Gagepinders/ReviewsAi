import { useState } from 'react'
import { fetchGeneratedResponse } from '../utils/openai'

export default function Dashboard() {
  const [review, setReview] = useState('')
  const [response, setResponse] = useState('')

  const handleGenerate = async () => {
    const result = await fetchGeneratedResponse(review)
    setResponse(result)
  }

  return (
    <div className="p-8">
      <h2 className="text-xl font-bold mb-4">Review Response Generator</h2>
      <textarea
        value={review}
        onChange={(e) => setReview(e.target.value)}
        placeholder="Paste a customer review..."
        className="w-full h-24 p-2 border"
      />
      <button onClick={handleGenerate} className="mt-2 bg-blue-600 text-white px-4 py-2 rounded">
        Generate Response
      </button>
      {response && (
        <div className="mt-4 p-4 bg-gray-100 border rounded">
          <h3 className="font-semibold">Suggested Response:</h3>
          <p>{response}</p>
        </div>
      )}
    </div>
  )
}