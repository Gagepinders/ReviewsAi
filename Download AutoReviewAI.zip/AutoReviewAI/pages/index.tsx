import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100">
      <h1 className="text-4xl font-bold mb-4">AutoReviewAI</h1>
      <p className="mb-6">Automate your reviews. Grow trust. Grow sales.</p>
      <Link href="/dashboard" className="bg-blue-600 text-white px-4 py-2 rounded">Go to Dashboard</Link>
    </div>
  )
}