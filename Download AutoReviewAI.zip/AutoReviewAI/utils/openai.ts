import axios from 'axios'

export async function fetchGeneratedResponse(review: string): Promise<string> {
  try {
    const response = await axios.post('/api/generate-response', { review })
    return response.data.result
  } catch (err) {
    return 'Error generating response.'
  }
}